#!/bin/bash

##################################
## Emergency script in case the ##
## miner crashes. User defined  ##
## actions to be inserted here  ##
##################################

echo "Hallo World from emergency script"
